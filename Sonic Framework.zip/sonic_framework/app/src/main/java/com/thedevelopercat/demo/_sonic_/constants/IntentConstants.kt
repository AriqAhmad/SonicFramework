package com.thedevelopercat.demo._sonic_.constants

enum class IntentConstants {
    FRAGMENT_TYPE,
    INT
}
