package com.thedevelopercat.sonic.rest

import com.thedevelopercat.sonic.model.SonicModel

open class SonicRequest: SonicModel()
