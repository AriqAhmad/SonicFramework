package com.thedevelopercat.sonic.ui.viewgroups

import android.content.Context
import android.util.AttributeSet
import androidx.appcompat.widget.LinearLayoutCompat

class SonicLinearLayout(context: Context, attrs: AttributeSet? = null) :
    LinearLayoutCompat(context, attrs) {
}