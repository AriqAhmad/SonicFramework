package com.thedevelopercat.sonic.viewModels

import androidx.lifecycle.ViewModel

open class SonicViewModel : ViewModel() {
}
